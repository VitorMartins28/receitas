<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand"> <i class="mdi mdi-logout mdi-flip-h voltar"> </i> Voltar</a>
        <button class="navbar-toggler" data-target="#my-nav" data-toggle="collapse" aria-controls="my-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div id="my-nav" class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Voltar as compras<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Ajuda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Sair</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-12">
                <form class="">
                    <div class="row">
                        <div class="col-8 col-md-6 mt-2">
                            <input class="form-control mr-sm-2" type="search" placeholder="Pesquisar" aria-label="Pesquisar">
                        </div>
                        <div class="col-4 col-md-6">
                            <button class="btn btn-success btn-col my-2 my-sm-0" type="submit">Pesquisar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-sm-12 ">
                <h4 class="text-center text-dark mt-4">Bebidas mais buscadas</h4>
            </div>
        </div>
        <?php
   
          
        
					//chamo minha conexão com o banco de dados...
					include('../conexao/conexao.php');
					//gero uma consulta de banco de dados...
					$sql = mysqli_query($conecta, "SELECT * FROM receitas");
					//listo os resultados encontrados na tela
					while($lista = mysqli_fetch_array($sql)){
						echo '
                            <div class=" mt-2">
                            <div class="col-12 col-md-12">
                                <div class="card">
                                    <img class="card-img-top" src="" alt="">
                                    <div class="card-body">
                                        <h5 class="card-title">'.$lista['nomeReceita'].'</h5>
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item">'.$lista['idReceita'].'</li>
                                            <li class="list-group-item">'.$lista['tempoDu'].'</li>
                                            <li class="list-group-item">'.$lista['Ingredientes'].'</li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
							';
					}
					?>
        <div class="row">
            <div class="col-12 mt-4 fixed-bottom">
                <footer class="rodape"> © Copyright 2020 Supermercado Caravelas</footer>
            </div>
        </div>
    </div>


    <!-- <p> <i class="mdi mdi-google-downasaur mdi-48px"></i></p> -->

    <script src="../js/jquery-3.4.1.js"></script>
    <script src="../js/bootstrap.js"></script>
    <script src="../libs/jQueryMask/jQuery-Mask-Plugin-master/dist/jquery.mask.js"></script>
    <script src="js/menu.js"></script>
</body>

</html>