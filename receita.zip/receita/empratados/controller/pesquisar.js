$(document).ready(function() {
    $('.btn-pesquisar').click(function(e) {
        e.preventDefault()

        $('.pesquisar').empty()

        var url = "empratados/model/pesquisar.php"

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: url,
            async: true,
            success: function(dados) {
                for (var i = 0; i < dados.length; i++) {
                    let pesquisar = `
                <div class=" mt-2">
                <div class="col-12 col-md-12">
                    <div class="card">
                        <img class="card-img-top" src="" alt="">
                        <div class="card-body">
                            <h5 class="card-title">` + dados[i].nomeReceita + `</h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">` + dados[i].tempoDu + `</li>
                                <li class="list-group-item">` + dados[i].Ingredientes + `</li>    
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
                `
                    $('.pesquisar').append(pesquisar)
                }
            }
        })
    })
})