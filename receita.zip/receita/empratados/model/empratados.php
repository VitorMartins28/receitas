<?php
    include_once('../../conexao/conexao.php');


    $sql = mysqli_query($conecta, "SELECT * FROM receitas");

    while($resultado = mysqli_fetch_assoc($sql)) {
        $receitas[] = array_map('utf8_encode', $resultado);
    }


    echo json_encode($receitas);
?>