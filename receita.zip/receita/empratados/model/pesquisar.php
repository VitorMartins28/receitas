<?php
    include_once('../../conexao/conexao.php');

    // $pesquisar = Print_r($_post["pesquisar"]);
   


    $sql = "SELECT * FROM receitas WHERE nomeReceita LIKE '%Suco%' LIMIT 5";
    $resultado = mysqli_query($conecta, $sql);

    while($dados = mysqli_fetch_array($resultado))
    {
        $pesquisar[] = array_map('utf8_encode', $dados);
    }
    
    echo json_encode('Suco');

?>


