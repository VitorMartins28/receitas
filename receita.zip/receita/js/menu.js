$(document).ready(function() {
    $('.bebidas').click(function() {
        $('body').load('bebidas/bebidas.php')
    })
    $('.doces').click(function() {
        $('body').load('doces/doces.php')
    })
    $('.empratados').click(function() {
        $('body').load('empratados/view/empratados.html')
    })
    $('.padaria').click(function() {
        $('body').load('padaria/padaria.php')
    })
    $('.voltar').click(function() {
        $('body').load('index.html')
    })
    $('.btnsubmit').click(function(e) {
        e.preventDefault()
    })
})