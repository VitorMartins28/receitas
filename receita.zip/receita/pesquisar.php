<?php
    //visualizar possível erros em código...
ini_set('display_errors', true);

//sempre me reportar em tela...
error_reporting(E_ALL);

//crio as variáveis que receberão as informações do banco...
$hostname = "localhost"; //local onde se encontra o banco...
$database = "receitas"; //nome do nosso banco de dados...
$username = "root"; //usuário de acesso ao banco de dados...
$password = "usbw"; //senha de acesso ao banco de dados...

//efetuar a conexão com o banco de dados...
//variável onde contará a minha conexão de banco...
$conecta = mysqli_connect($hostname, $username, $password, $database);
if (isset($conecta)) {
	// echo "Conexão efetuada com sucesso!";
}else{
	echo "Erro ao efetuar a conexão: ".mysqli_error($conecta);
}
    
    $pesquisar = $_POST['pesquisar'];
    $result_receita = "SELECT * FROM receitas WHERE nomeReceita LIKE '%$pesquisar%' LIMIT 5";
    $resultado_receita = mysqli_query($conecta, $result_receita);

    while($rows_receita = mysqli_fetch_array($resultado_receita))
    {
        echo '
            <div class=" mt-2">
            <div class="col-12 col-md-12">
                <div class="card">
                    <img class="card-img-top" src="" alt="">
                    <div class="card-body">
                        <h5 class="card-title">'.$rows_receita['nomeReceita'].'</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">'.$rows_receita['idReceita'].'</li>
                            <li class="list-group-item">'.$rows_receita['tempoDu'].'</li>
                            <li class="list-group-item">'.$rows_receita['Ingredientes'].'</li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
            ';
    }
?>